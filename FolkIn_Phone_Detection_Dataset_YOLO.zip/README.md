# FolkIn Phone Detection Dataset (converted)

Source: Roboflow Universe, Phone_in_hand, version 10
Source URL: https://universe.roboflow.com/phone-in-hand/phone_in_hand-lcqvm/dataset/10
License stated by source: CC BY 4.0. Preserve attribution when redistributing or publishing results.

This package was converted from the provided YOLO26 export to standard YOLO object-detection labels.
- Polygon segmentation annotations (class 0) were converted to axis-aligned bounding boxes.
- Existing four-number YOLO bounding boxes (class 1) were retained.
- Empty label files are retained for images with no annotated objects.
- Original train/valid/test split is retained.
- No images from the user's personal webcam dataset were added, because those images have not yet been annotated.

Classes:
0: phone_in_hand (source polygon surrounds the hand-held phone/hand region; bounding box is an approximation)
1: phone (source phone bounding box)

Important:
This is a starter dataset. Inspect visual annotations before training. The `phone_in_hand` box can include the hand as well as the phone, so this model detects a phone-in-hand scene region, not a precise phone-only box. Performance on a user's webcam may differ from source images. Test on separate user-specific images before relying on alerts.
